<a href={{ route('score-categories') }} class="nav-link">                    
  <i class="fas fa-tasks mr-2"></i>
  Score Categories
</a>