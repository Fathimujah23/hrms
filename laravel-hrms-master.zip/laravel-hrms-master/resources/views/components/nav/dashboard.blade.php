<a href="{{ route('dashboard') }}" class="nav-link">
  <i class="fas fa-tachometer-alt mr-2"></i>
  Dashboard
</a>