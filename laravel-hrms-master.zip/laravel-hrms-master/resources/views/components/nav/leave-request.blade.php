<a href={{ route('employees-leave-request') }} class="nav-link">
  <i class="fas fa-walking mr-2"></i>
  Employees' Leave Requests
</a>