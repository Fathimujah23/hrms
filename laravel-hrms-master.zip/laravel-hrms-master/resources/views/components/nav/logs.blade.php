<a href={{ route('logs') }} class="nav-link">
  <i class="fas fa-file mr-2"></i>
  Logs
</a>