<a href={{ route('attendances') }} class="nav-link">
  <i class="fas fa-calendar-check mr-2"></i>
  Attendances
</a>