<a href={{ route('employees-performance-score') }} class="nav-link">
    <i class="fas fa-chart-line mr-2"></i>
    Employees' Performance Score
</a>