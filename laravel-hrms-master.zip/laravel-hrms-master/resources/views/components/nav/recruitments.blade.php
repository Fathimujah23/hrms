<a href={{ route('recruitments') }} class="nav-link">                    
  <i class="fas fa-briefcase mr-2"></i>
  Recruitments
</a>