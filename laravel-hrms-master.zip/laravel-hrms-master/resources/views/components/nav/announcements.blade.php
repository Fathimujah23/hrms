<a href={{ route('announcements') }} class="nav-link">
  <i class="fas fa-bullhorn mr-2"></i>
  Announcements
</a>