<a href="#accountSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle nav-link">
    <i class="fas fa-users mr-2"></i>
    Accounts
</a>
<ul class="collapse list-unstyled" id="accountSubmenu">
    <li class="nav-item">
        <a href={{ route('users') }} class="nav-link">Users</a>
    </li>
    <li class="nav-item">
        <a href={{ route('roles') }} class="nav-link">Roles</a>
    </li>
</ul>