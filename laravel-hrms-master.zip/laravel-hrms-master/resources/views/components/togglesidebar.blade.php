<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-fluid">
      <button type="button" id="sidebarCollapse" class="btn btn-info toggleSidebarButton">
          <span class="navbar-toggler-icon"></span>
      </button>
  </div>
</nav>